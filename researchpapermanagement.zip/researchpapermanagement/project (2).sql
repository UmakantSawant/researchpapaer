-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 14, 2022 at 02:00 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `login_tyminip`
--

CREATE TABLE `login_tyminip` (
  `id` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rl` varchar(255) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `clgname` varchar(255) NOT NULL,
  `brnm` varchar(255) NOT NULL,
  `bdt` date DEFAULT NULL,
  `mbn` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login_tyminip`
--

INSERT INTO `login_tyminip` (`id`, `username`, `password`, `rl`, `fname`, `lname`, `clgname`, `brnm`, `bdt`, `mbn`) VALUES
(12, 'ishanksawant22@gmail.com', '$2y$10$XN7NYlniP8tVejuhDasZa.SIaMJkI8x.upRoRmWn/XPDrquKU99oK', 'Student', 'Shantanu', 'Sawant', 'SVKM IOT', 'Computer Science', '2022-07-11', '9452145784'),
(17, 'asd@asd.com', '$2y$10$.JFWJQDF3e4efEAMQ49alemPNAsXDPMuMroVBzhMn0wSm3fGvS9X6', 'Admin', 'Umakant', 'Sawant', 'SVKM IOT', 'Computer Science', '2022-07-29', '9158392510'),
(18, 'admin@123', '$2y$10$iXp2pK5PAXfjIaCWsH3eFuMb3Zx2MfRlzTusypa7FkkEy57Qt8PIu', 'Developer', 'Shantanu', 'Sawant', 'SVKM IOT', 'Information Technology', '2022-09-12', '9158392510');

-- --------------------------------------------------------

--
-- Table structure for table `tyminip`
--

CREATE TABLE `tyminip` (
  `id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `rpn` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `pub_dt` date NOT NULL,
  `type` varchar(255) NOT NULL,
  `keyword` varchar(255) NOT NULL,
  `volume` varchar(255) NOT NULL,
  `nmcj` varchar(255) DEFAULT NULL,
  `pg` varchar(255) DEFAULT NULL,
  `weblink` varchar(255) DEFAULT NULL,
  `filename` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tyminip`
--

INSERT INTO `tyminip` (`id`, `user_id`, `rpn`, `author`, `pub_dt`, `type`, `keyword`, `volume`, `nmcj`, `pg`, `weblink`, `filename`) VALUES
(4, 0, 'A New IoT Gateway for Artificial Intelligence in Agriculture', 'Marco Barenkamp', '2020-06-13', 'conference', 'AI', '', 'N.A', 'N.A', 'N.A', 'A_New_IoT_Gateway_for_Artificial_Intelligence_in_Agriculture.pdf'),
(5, 0, 'BIoT: Blockchain based Smart Agriculture with Internet of Thing', 'Milon Biswas', '2021-06-18', 'conference', 'Agriculture', '', 'N.A', 'N.A', 'N.A', 'BIoT_Blockchain_based_Smart_Agriculture_with_Internet_of_Thing.pdf'),
(23, 12, 'Developing an AI IoT application with open software on a RISC-V SoC', 'Enrique Torres-Sanchez', '2020-04-14', 'Journal', 'AI IoT', 'asdsad', 'N.A', 'N.A', 'N.A', '._A_New_IoT_Gateway_for_Artificial_Intelligence_in_Agriculture.pdf'),
(24, 12, 'EMBEDDED ARTIFICIAL INTELLIGENCE  APPROACH FOR GAS RECOGNITION IN  SMART AGRICULTURE APPLICATIONS USING  LOW COST MOX GAS SENSORS', 'Claudia Bruno', '2021-05-06', 'Journal', 'ARTIFICIAL INTELLIGENCE', 'desc', 'N.A', 'N.A', 'N.A', '._IoT_Indoor_Localization_with_AI_Technique.pdf'),
(27, 17, 'after adding fields', 'jhb', '2022-07-05', 'conference', 'asd', 'V1', 'IEEE', '234', 'sdas', 'jayesh plagarism report turn it in.pdf'),
(28, 18, 'may be', 'azx', '2022-08-31', 'gernal', 'sdsa', 'V1', 'IEEE', '234', 'sdsds', 'Umakant Sawant Resume.pdf');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login_tyminip`
--
ALTER TABLE `login_tyminip`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tyminip`
--
ALTER TABLE `tyminip`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login_tyminip`
--
ALTER TABLE `login_tyminip`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tyminip`
--
ALTER TABLE `tyminip`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

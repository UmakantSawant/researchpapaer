<?php
require_once "../config/config.php";
$username = $password = $confirm_password = "";
$username_err = $password_err = $confirm_password_err = "";

$blk_usernm= false;
$tkn_usernm= false;
$swr = false;
$swr1 = false;
$lnps=false;
$blps=false;
$nmps=false;
$tkn_usernm= false;
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    //EMPTY USERNAME
    $role = $_POST["rl"];
    if (empty(trim($_POST["username"]))) {
        $username_err == "Username cannot be blanked";
        $blk_usernm= true;
    } else {
        $sql = "SELECT id FROM login_tyminip WHERE username = ?";
        $stmt = mysqli_prepare($conn, $sql);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "s", $param_username);

            //set value of param_usernae
            $param_username = trim($_POST['username']);


            //try to execute stmt
            if (mysqli_stmt_execute($stmt)) {
                mysqli_stmt_store_result($stmt);
                if (mysqli_stmt_num_rows($stmt) == 1) {
                    $username_err = "This username is already taken";
                    $tkn_usernm= true;
                } else {
                    $username = trim($_POST['username']);
                    
                }
            } else {
                echo "Something went wrong";
                $swr = true;
            }
        }
        mysqli_stmt_close($stmt);
    }
    


    //check for password
    if (empty(trim($_POST['password']))) {
        $password_err = "password cannot be blanked";
        $blps = true;
    } elseif (strlen(trim($_POST['password'])) < 5) {
        $password_err = "password greater than 5";
        echo $password_err;
        $lnps=true;
    } else {
        $password = trim($_POST['password']);
    }
    //check for confirm password field
    if (trim($_POST['password']) != trim($_POST['confirm_password'])) {
        $password_err = "password should match";
        $nmps = true;
    }
    //fi no error go ahead & insert to database

    if (empty($username_err) && empty($password_err) && empty($confirm_password_err)) {

        $fname = $_POST["fname"];
        $lname = $_POST["lname"];
        $clgname = $_POST["clgname"];
        $brnm = $_POST["brnm"];
        $bdt = $_POST["bdt"];
        $mbn = $_POST["mbn"];




        $sql = "INSERT INTO login_tyminip (username, password,rl,fname,lname,clgname,brnm,bdt,mbn) VALUES(?,?,'$role','$fname','$lname','$clgname','$brnm','$bdt',$mbn)";
        
       
        $stmt = mysqli_prepare($conn, $sql);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "ss", $param_username, $param_password);

            //set these para
            $param_username = $username;
            $param_password = password_hash($password, PASSWORD_DEFAULT);
            
            // TRY TO EXECUTE QUERY
            if (mysqli_stmt_execute($stmt)) {
                header("location: ../templates/login.php");
            } else {
                echo "Something went wrong... redirect";
                $swr1 = true;
            }
            
        }
        mysqli_stmt_close($stmt);
        
    }
    
}
mysqli_close($conn);
?>



















<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Research Paper Management System</title>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Research Paper Management System</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Register <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="login.php">Login</a>
                </li>
               



            </ul>
        </div>
    </nav>
    <?php










    if ($blk_usernm) {
        echo "<div class='alert alert-danger alert-dismissible fade show' role='alert'>
        Email can not be blanked
        <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
    <span aria-hidden='true'>&times;</span>
  </button>
      </div>";
    }
    elseif ($swr) {
        echo "<div class='alert alert-danger' alert-dismissible fade show' role='alert'>
        Error return 0
        <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
    <span aria-hidden='true'>&times;</span>
  </button>
      </div>";
    }
    elseif ($swr1) {
        echo "<div class='alert alert-danger' alert-dismissible fade show' role='alert'>
        Error return 1
        <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
    <span aria-hidden='true'>&times;</span>
  </button>
      </div>";
    }
    elseif ($lnps) {
        echo "<div class='alert alert-danger' alert-dismissible fade show' role='alert'>
        Password must be greater than 5 charecters
        <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
    <span aria-hidden='true'>&times;</span>
  </button>
      </div>";
    }
    elseif ($blps) {
        echo "<div class='alert alert-danger' alert-dismissible fade show' role='alert'>
        Password can not be blanked
        <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
    <span aria-hidden='true'>&times;</span>
  </button>
      </div>";
    }
    elseif ($nmps) {
        echo "<div class='alert alert-danger' alert-dismissible fade show' role='alert'>
        Passwords should match
        <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
    <span aria-hidden='true'>&times;</span>
  </button>
      </div>";
    }
    elseif ($tkn_usernm) {
        echo "<div class='alert alert-danger' alert-dismissible fade show' role='alert'>
        Username already taken
        <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
    <span aria-hidden='true'>&times;</span>
  </button>
      </div>";
    }
    ?>
    <div class="container mt-4">
        <h3>Please Register Here:</h3>
        <hr>
        <form action="" method="post">
            <div class="form-row">
            <div class="form-group col-md-6 mb-3">
                    <label for="fname">First Name</label>
                    <input type="text" class="form-control" name="fname" id="fname" placeholder="First Name">
                </div>
                <div class="form-group col-md-6">
                    <label for="lname">Last Name</label>
                    <input type="text" class="form-control" name="lname" id="lname" placeholder="Last Name">
                </div>
                
                <div class="form-group col-md-6">
                    <label for="clgname">College Name</label>
                    <select name="clgname" id="clgname" class="form-control">
                        <option selected>Choose...</option>
                        <option>SVKM IOT</option>       
                    </select>
                </div>

                <div class="form-group col-md-6">
                    <label for="brnm">Branch</label>
                    <select name="brnm" id="brnm" class="form-control">
                        <option selected>Choose...</option>
                        <option>Information Technology</option>  
                        <option>Computer Science</option> 
                               
                    </select>
                </div>



                <div class="form-group col-md-6">
                    <label for="inputEmail4">Email</label>
                    <input type="email" class="form-control" name="username" id="inputEmail4" placeholder="Email">
                </div>
                <div class="form-group col-md-6">
                    <label for="mbn">Mobile Number:</label>
                    <input type="tele" class="form-control" name="mbn" id="mbn" placeholder="Mobile Number">
                </div>
                <div class="form-group col-md-6">
                    <label for="inputPassword4">Password</label>
                    <input type="password" class="form-control" name="password" id="inputPassword4" placeholder="Password">
                </div>

                <div class="form-group col-md-6">
                <label for="inputPassword4">Confirm Password</label>
                <input type="password" class="form-control" name="confirm_password" id="inputPassword" placeholder="Confirm Password">
            </div>
            <div class="form-group col-md-6">
                    <label for="bdt">Enter Birth Date</label>
                    <input type="date" class="form-control" name="bdt" id="bdt">
                </div>
          
                <div class="form-group col-md-4">
                    <label for="inputState">Role</label>
                    <select name="rl" id="inputState" class="form-control">
                        <option selected>Choose...</option>
                        <option>Admin</option>
                        <option>Teacher</option>
                        <option>Student</option>
                        <option>Developer</option>
                        
                    </select>
                </div>
                
            </div>
            <button type="submit" class="btn btn-primary">Sign Up</button>

            </div>
            
            
            
        </form>
    </div>
    <!-- js for close alert bts -->
    <script>
        $('.alert').alert()
    </script>


    
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>

</html>
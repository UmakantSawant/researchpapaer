<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
}



require_once("../config/config.php");

$insert = false;
$update = false;
$delete = false;


$user = $_SESSION["username"];




$r= "SELECT * from login_tyminip where username='$user'";
$rs = mysqli_query($conn, $r);
$row12 = mysqli_fetch_assoc($rs);
   $rrole=  $row12['rl']  ;
   


$showme=false;


 if($rrole == "Admin" ){
    $showme = true;
    
 }
 else{
    $showme = false;
 }
  



if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] == true) {
    if (isset($_GET['delete'])) {
        $id = $_GET['delete'];
        $delete = true;
        $sql = "DELETE FROM `login_tyminip` WHERE `id` = $id";
        $result = mysqli_query($conn, $sql);
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        if (isset($_POST['editid'])) {
            $update = true;
            $id = $_POST["editid"];
            $edfn = $_POST["edfn"];
            
            $edln = $_POST["edln"];
            $edem = $_POST["edem"];
            $edrl = $_POST["edrl"];
            $edclg = $_POST["edclg"];
            $edbrnm = $_POST["edbrnm"];
            $edmb = $_POST["edmb"];
            $edbdt = $_POST["edbdt"];
            
            


            $sql = "UPDATE `login_tyminip` SET `edfn` = '$edfn', `edln` = '$edln', `edem` = '$edem', `edrl` = '$edrl', `edclg` = '$edclg',, `edbrnm` = '$edbrnm', `edbdt` = '$edbdt', `edmb` = '$edmb' WHERE `login_tyminip`.`id` = $id";
            $result = mysqli_query($conn, $sql);
            if ($result) {
                $update = true;
            } else {

                echo "nope";
            }
        }
    }
}





$r= "SELECT * from login_tyminip where username='$user'";
                $rs = mysqli_query($conn, $r);
                $row12 = mysqli_fetch_assoc($rs);
                   $fn=  $row12['fname']  ;
                   $ln=  $row12['lname']  ;
                   $mb=  $row12['mbn']  ;
                   $em=  $row12['username']  ;
                   $bd=  $row12['bdt']  ;
                   $cl=  $row12['clgname']  ;
                   $br=  $row12['brnm']  ;
                   $rl=  $row12['rl']  ;









?>















<!DOCTYPE html>
<html lang="en">

<head>
    <!-- CSS only -->

    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">

    <link rel="stylesheet" href="../css/logout.css">
    <link rel="stylesheet" href="../css/additem.css">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/inventory.css">

    <style type="text/css">
 .lgot{
   position:absolute;
   top:0;
   right:10px;
  }
</style>



    <title>Research Paper Management System</title>



</head>

<body>
    <!-- Edit modal -->
    <!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#editModal">
        Edit Modal
    </button> -->

    <!--Edit Modal 
    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Edit Inventory</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <form action="inventory.php" name="f1" method="POST">
                        <input type="hidden" name="editid" id="editid">
                        <label for="compony">Company:</label>
                        <input type="text" id="editcompany" name="editcompany" placeholder="Company Name">
                        <br>
                        <label for="lable">Lable for easy search:</label>
                        <select id="editlable" name="editlable">
                            <option value="shirt">Shirt</option>
                            <option value="tshirt">T Shirt</option>
                            <option value="pant">Pant</option>
                            <option value="jacket">Jacket</option>
                            <option value="cotton">Cotton</option>
                            <option value="Other">Other</option>
                        </select>

                        <label for="productname">Product Name:</label>
                        <input type="text" id="editproductname" name="editproductname" placeholder="Product Name">
                        <br>
                        <label for="quantity">Quantity:</label>
                        <input type="text" id="editquantity" name="editquantity" placeholder="Enter quantity">
                        <br>
                        <label for="sellprice">Price per indivisual:</label>
                        <input type="text" id="editpricesell" name="editpricesell" placeholder="Enter price per individual">
                        <br>
                        <label for="originalprice">Original Price:</label>
                        <input type="text" id="editpriceoriginal" name="editpriceoriginal" placeholder="Enter original price per individual">


                        <br>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div>-->

        <!--Edit Modal -->
        <div class="lgot">
            <a href="logout.php">Logout</a>
        </div>
    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Edit Inventory</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <form action="Super.php" name="f1" method="POST">
                        <input type="hidden" name="editid" id="editid">
                        <label for="fnm">First Name:</label>
                        <input type="text"   id="editrpn" name="edfn" placeholder="First Name">
                        <br>
                        
                        <label for="lnm">Last Name:</label>
                        <input  type="text" id="edln" name="edln" placeholder="Last Name">
                        <br>
                        <label for="email">Email</label>
                        <input  type="email" id="editpub_dt" name="edem" placeholder="Email ">
                        <br>
                        <label for="Role">Role</label>
                        
                        <select name="edrl" id="inputState" class="form-control">
                        <option selected></option>
                        <option>Admin</option>
                        <option>Teacher</option>
                        <option>Student</option>
                        <option>Developer</option>
                        
                    </select>
                    <label for="edclg">College Name</label>
                    <select name="edclg"  id="clgname" class="form-control">
                        
                        <option>SVKM IOT</option>       
                    </select>
                    
                        <br>

                        
                        <br>
                        <label for="brnm">Branch</label>
                    <select   name="edbrnm" id="brnm" class="form-control">
                        
                        <option>Information Technology</option>  
                        <option>Computer Science</option> 
                               
                    </select>
                        

                        <br>
                        <label for="mbn">Mobile Number:</label>
                    <input type="tele" class="form-control"  name="edmb" id="mbn" placeholder="Mobile Number">

                    <label for="edbd">Enter Birth Date</label>
                    <input  type="date"  class="form-control" name="edbdt" id="bdt">


                        <button type="submit" class="btn btn-primary">Update</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                   
                </div>
            </div>
        </div>
    </div>











    <div class="topbar">
        <div class="logo">
            <h2>Research Paper <span>Management System</span></h2>
        </div>
        <!-- <div class="ca">
            <div class="cabt">
                <div class="invtop">
                    <button class="button">Inventory</button>
                </div>

            </div>
        </div> -->
        <!-- <div class="user">
            <h4>
                
            </h4>
             <img src="../img/pexels-bich-tran-669996.jpg" alt=""> -->
    </div>
    </div>
    <div class="navinv">
        <div class="wrapper">
            <a href="./index.php"><span>Home</span></a>
        </div>

        
        <div class="wrapper">
            <a href="./add.php"><span>Add Paper</span></a>
        </div>
        <div class="wrapper">
            <a href="profile.php"><span>Profile</span></a>
        </div>

        <?php if($showme){echo"
            <div class='wrapper'>
            <a href='Super.php'><span>Users</span></a>
        </div>";
        } ?>
        
    </div>

    <?php

    if ($update) {
        echo "<div class='alert alert-success' role='alert'>
Item updated Successfull!!:)
</div>";
    }
    ?>

    <?php
    if ($delete) {
        echo "<div class='alert alert-success' role='alert'>
Item Delete Successfull!! :)
</div>";
    }
    ?>

    <div class="searchinv">
        <div class="searchb1">
            <form autocomplete="off" action="">
                <div class="d-flex justify-content-center px-5">
                    <input type="search" placeholder="Search..." class="form-control search-input" data-table="customers-list" style="width: 80vw; border: 1px solid black; margin-top: 60px; margin-bottom: -10px;" />


                </div>

        </div>

    </div>
    <div class="mbt">


        <table class="table table-striped mt32 customers-list" style="margin-top: 30px; ">
       
            <thead>
                <tr>
                    <th>S.No</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>College</th>
                    <th>Branch</th>
                    <th>Contact No.</th>
                    <th>Birth Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <?php
            //$sql1 = ("SELECT * FROM tyminip where username='$user'");
            //$result1 = mysqli_query($conn, $sql1);
            //$row = mysqli_fetch_assoc($result1);
            //print_r($row);
            ?>
            <tbody>
                <?php




$id = $_SESSION["id"];
$r= "SELECT * from login_tyminip where username='$user'";
$rs = mysqli_query($conn, $r);
$row12 = mysqli_fetch_assoc($rs);
   $rrole=  $row12['rl']  ;
   
   
   



    $sql = "SELECT * FROM login_tyminip";
                $result = mysqli_query($conn, $sql);

                $id = 0;
                while ($row = mysqli_fetch_assoc($result)) {
                   $id = $id + 1;
                    
                   
                   
                    

                   


                    

                    echo "<tr>
                        <th scope='row'>" . $id . "</th>
                <td>" . $row['fname'] . "</td>
                <td>" . $row['lname'] . "</td>
                <td>" . $row['username'] . "</td>
                <td>" . $row['rl'] . "</td>
                <td>" . $row['clgname'] . "</td>
                <td>" . $row['brnm'] . "</td>
                <td>" . $row['mbn'] . "</td>
                <td>" . $row['bdt'] . "</td>
                <td><button type='button' class='edit btn btn-sm btn-primary' id=" . $row['id'] . " >Edit</button> <button type='button' class='delete btn btn-sm btn-primary'  id=d" . $row['id'] . ">Delete</button></td>
                
                <td></td>
                 
            </tr>";
    }








   

                ?>



            </tbody>
        </table>
    </div>
    <!-- for search filter -->
    <script>
        (function(document) {
            'use strict';

            var TableFilter = (function(myArray) {
                var search_input;

                function _onInputSearch(e) {
                    search_input = e.target;
                    var tables = document.getElementsByClassName(search_input.getAttribute('data-table'));
                    myArray.forEach.call(tables, function(table) {
                        myArray.forEach.call(table.tBodies, function(tbody) {
                            myArray.forEach.call(tbody.rows, function(row) {
                                var text_content = row.textContent.toLowerCase();
                                var search_val = search_input.value.toLowerCase();
                                row.style.display = text_content.indexOf(search_val) > -1 ? '' : 'none';
                            });
                        });
                    });
                }

                return {
                    init: function() {
                        var inputs = document.getElementsByClassName('search-input');
                        myArray.forEach.call(inputs, function(input) {
                            input.oninput = _onInputSearch;
                        });
                    }
                };
            })(Array.prototype);

            document.addEventListener('readystatechange', function() {
                if (document.readyState === 'complete') {
                    TableFilter.init();
                }
            });

        })(document);
    </script>
    <!-- end search filter -->
    </div>
    </div>

    <!-- modal -->
    <!-- jQuery -->

    <!-- end modal -->

    <!-- MODAL TOGGLE STRT -->



    <!-- MODAL TOGGLE ENDS -->
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>





    <script>
        edits = document.getElementsByClassName('edit');
        Array.from(edits).forEach((element) => {
            element.addEventListener("click", (e) => {
                console.log("edit ", );
                tr = e.target.parentNode.parentNode;
                fn = tr.getElementsByTagName("td")[0].innerText;
                ln = tr.getElementsByTagName("td")[1].innerText;
                em = tr.getElementsByTagName("td")[2].innerText;
                rl = tr.getElementsByTagName("td")[3].innerText;
                clg = tr.getElementsByTagName("td")[4].innerText;
                br = tr.getElementsByTagName("td")[5].innerText;
                mb = tr.getElementsByTagName("td")[6].innerText;
                bd = tr.getElementsByTagName("td")[7].innerText;
                
                console.log(fn, ln, em, rl, clg);
                fn.value = fn;
                ln.value = ln;
                em.value = em;
                rl.value = rl;
                clg.value = clg;
                brnm.value = br;
                mb.value = mb;
                bdt.clg = bd;

                
                editid.value = e.target.id;

                console.log(e.target.id);
                $('#editModal').modal('toggle');
                console.log(e.target.datetime);

            })
        })

        //for delete ...down
        deletes = document.getElementsByClassName('delete');
        Array.from(deletes).forEach((element) => {
            element.addEventListener("click", (e) => {
                console.log("edit ");

                id = e.target.id.substr(1);

                if (confirm("Are you sure you want to delete this note!")) {
                    console.log("yes");
                    $del = window.location = `/Mini/templates/Super.php?delete=${id}`;
                    if ($del == true) {
                        window.location.reload("Super.php");
                    }

                    // TODO: Create a form and use post request to submit a form
                } else {
                    console.log("no");
                }


            })
        })
    </script>







</body>

</html>
<?php
 session_start();






 require_once("../config/config.php");
$invd = false;
$suc = false;
$invd1 = false;
$ups=false;
$ups1=false;
$user = $_SESSION["username"];


$r= "SELECT * from login_tyminip where username='$user'";
$rs = mysqli_query($conn, $r);
$row12 = mysqli_fetch_assoc($rs);
   $rrole=  $row12['id']  ;
   //echo $rrole;
            










if (isset($_POST['upd']))
	{
	$fnm = $_POST['fname'];
    $bdt = $_POST['bdt'];
	$lnm = $_POST['lname'];
	$clgnm = $_POST['clgname'];
    $brnm = $_POST['brnm'];
	
	// $password_query = ("SELECT * from login_tyminip where `id`='$rrole'");
    // $res = mysqli_query($conn,$password_query);
	// $password_row = mysqli_fetch_array($res);
	
			
                
			$update_pwd = "UPDATE login_tyminip set `fname`='$fnm', `bdt`='$bdt', `lname`='$lnm', `clgname`='$clgnm', `brnm`='$brnm' where `id`='$rrole'";
            $re1 = mysqli_query($conn,$update_pwd);

            
            if($re1){
                $ups=true;
            }
            else{
                $ups1=true;
            }
            
            
                // $param_password = password_hash($new_pass, PASSWORD_DEFAULT);
                
                // // TRY TO EXECUTE QUERY
                // if ($param_password) {
                //     echo "hash done";
                // } else {
                //     echo "Something went wrong... redirect";
                //     $swr1 = true;
                // }

                    


			//echo "('Update Sucessfully')";
                }
		
                $r= "SELECT * from login_tyminip where username='$user'";
                $rs = mysqli_query($conn, $r);
                $row12 = mysqli_fetch_assoc($rs);
                   $fn=  $row12['fname']  ;
                   $ln=  $row12['lname']  ;
                   $mb=  $row12['mbn']  ;
                   $em=  $row12['username']  ;
                   $bd=  $row12['bdt']  ;
                   $cl=  $row12['clgname']  ;
                   $br=  $row12['brnm']  ;
                   $rl=  $row12['rl']  ;
                   
                   //echo $rrole;
	
 
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <!-- Required meta tags -->
   <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/logout.css">
    <title>Research Paper Management System</title>

    <style>
        body{
            background-color: black;
            color: wheat;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Research Paper Management System</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="admin.php">Admin <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="profile.php">Profile</a>
                </li>
               



            </ul>
        </div>
    </nav>
<?php 
    if ($ups) {
        echo "<div class='alert alert-success alert-dismissible fade show' role='alert'>
        Information Updated Successfully
        <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
    <span aria-hidden='true'>&times;</span>
  </button>
      </div>";
    }
    elseif($ups1) {
        echo "<div class='alert alert-danger' alert-dismissible fade show' role='alert'>
        Problem Updating. Please try again later
        <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
    <span aria-hidden='true'>&times;</span>
  </button>
      </div>";
    }
    


?>





    <div class="container mt-4">
        <h3>Update Information</h3>
        <hr>
        <form action="" method="post">
            <div class="form-row">
            
            




            <div class="container mt-4">
       
        <hr>
        <form action="" method="post">
            <div class="form-row">
            <div class="form-group col-md-6 mb-3">
                    <label for="fname">First Name</label>
                    <input type="text" value="<?php echo $fn; ?>" class="form-control" name="fname" id="fname" placeholder="First Name">
                </div>
                <div class="form-group col-md-6">
                    <label for="lname">Last Name</label>
                    <input type="text" class="form-control" value="<?php echo $ln; ?>" name="lname" id="lname" placeholder="Last Name">
                </div>
                
                <div class="form-group col-md-6">
                    <label for="clgname">College Name</label>
                    <select name="clgname" value="<?php echo $cl; ?>" id="clgname" class="form-control">
                        
                        <option>SVKM IOT</option>       
                    </select>
                </div>

                <div class="form-group col-md-6">
                    <label for="brnm">Branch</label>
                    <select name="brnm" id="brnm" class="form-control">
                        <option selected><?php echo $br; ?></option>
                        <option>Information Technology</option>  
                        <option>Computer Science</option> 
                               
                    </select>
                </div>



                <div class="form-group col-md-6">
                    <label for="inputEmail4">Email</label>
                    <input type="email" value="<?php echo $em; ?>" class="form-control" name="username" id="inputEmail4" placeholder="Email">
                </div>
                <div class="form-group col-md-6">
                    <label for="mbn">Mobile Number:</label>
                    <input type="tele" class="form-control" value="<?php echo $mb; ?>" name="mbn" id="mbn" placeholder="Mobile Number">
                </div>
                
            <div class="form-group col-md-6">
                    <label for="bdt">Enter Birth Date</label>
                    <input type="date" value="<?php echo $bd; ?>" class="form-control" name="bdt" id="bdt">
                </div>
          
               
                
            </div>
            <button type="submit" name="upd" class="btn btn-primary">Update</button>

            </div>
            
            
            
        </form>
    </div>




        <script>
        $('.alert').alert()
    </script>


<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
















<!-- <div style="width:30%;">
   <form method="post" action="">
      <div>
         <label style="color:blue;">Email</label>
         <input type="email" name="username" placeholder="Enter email">
      </div>
      <div>
         <label style="color:blue;">Bdt</label>
         <input type="date" name="bdt" placeholder="Enter bdt">
      </div>
      <div>
         <label style="color:blue;">New Password</label>
         <input type="password" name="new_pass" placeholder="New Password . . . . .">
      </div>
      <div>
         <label style="color:blue;">Re-Type New Password</label>
         <input type="password" name="re_pass" placeholder="Re-Type New Password . . . . .">
      </div>
      <button type="submit" name="re_password">Submit</button>
   </form>
</div>
</body>
</html> -->
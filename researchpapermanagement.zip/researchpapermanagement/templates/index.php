<?php
session_start();




require_once("../config/config.php");

$insert = false;
$update = false;
$delete = false;























?>















<!DOCTYPE html>
<html lang="en">

<head>
    <!-- CSS only -->

    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="../css/logout.css">

    <link rel="stylesheet" href="../css/additem.css">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/inventory.css">





    <title>Research Paper Management System</title>



</head>

<body>
    <!-- Edit modal -->
    <!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#editModal">
        Edit Modal
    </button> -->

    <!--Edit Modal 
    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Edit Inventory</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <form action="inventory.php" name="f1" method="POST">
                        <input type="hidden" name="editid" id="editid">
                        <label for="compony">Company:</label>
                        <input type="text" id="editcompany" name="editcompany" placeholder="Company Name">
                        <br>
                        <label for="lable">Lable for easy search:</label>
                        <select id="editlable" name="editlable">
                            <option value="shirt">Shirt</option>
                            <option value="tshirt">T Shirt</option>
                            <option value="pant">Pant</option>
                            <option value="jacket">Jacket</option>
                            <option value="cotton">Cotton</option>
                            <option value="Other">Other</option>
                        </select>

                        <label for="productname">Product Name:</label>
                        <input type="text" id="editproductname" name="editproductname" placeholder="Product Name">
                        <br>
                        <label for="quantity">Quantity:</label>
                        <input type="text" id="editquantity" name="editquantity" placeholder="Enter quantity">
                        <br>
                        <label for="sellprice">Price per indivisual:</label>
                        <input type="text" id="editpricesell" name="editpricesell" placeholder="Enter price per individual">
                        <br>
                        <label for="originalprice">Original Price:</label>
                        <input type="text" id="editpriceoriginal" name="editpriceoriginal" placeholder="Enter original price per individual">


                        <br>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div>-->



    <div class="topbar">
        <div class="logo">
            <h2>Research Paper <span>Management System</span></h2>
        </div>
        <!-- <div class="ca">
            <div class="cabt">
                <div class="invtop">
                    <button class="button">Inventory</button>
                </div>

            </div>
        </div> -->
        <!-- <div class="user">
            <h4>
                //<?php echo " " . $_SESSION['username']; ?>
            </h4>
             <img src="../img/pexels-bich-tran-669996.jpg" alt=""> -->
    </div>
    </div>
    <div class="navinv">
        <div class="wrapper">
            <a href="./index.php"><span>Home</span></a>
        </div>

        
        <div class="wrapper">
            <a href="./admin.php"><span>My Papers</span></a>
        </div>
    </div>

    <?php

    if ($update) {
        echo "<div class='alert alert-success' role='alert'>
Item updated Successfull!!:)
</div>";
    }
    ?>

    <?php
    if ($delete) {
        echo "<div class='alert alert-success' role='alert'>
Item Delete Successfull!! :)
</div>";
    }
    ?>

    <div class="searchinv">
        <div class="searchb1">
            <form autocomplete="off" action="">
                <div class="d-flex justify-content-center px-5">
                    <input type="search" placeholder="Search..." class="form-control search-input" data-table="customers-list" style="width: 80vw; border: 1px solid black; margin-top: 60px; margin-bottom: -10px;" />


                </div>

        </div>

    </div>
    <div class="mbt">


        <table class="table table-striped mt32 customers-list" style="margin-top: 30px; ">
            <thead>
                <tr>
                    <th>S.No</th>
                    <th>Research Paper Name</th>
                    <th>Author</th>
                    <th>Publish Date</th>
                    <th>Type</th>
                    <th>Keyword</th>
                    <th>Volume</th>
                    <th>Name of conference/journal</th>
                    <th>Page</th>
                    <th>Weblink</th>

                    
                    <th>Download</th>
                </tr>
            </thead>
            <?php
            $sql1 = "SELECT * FROM tyminip";
            ?>
            <tbody>
                <?php






                $sql = "SELECT * FROM `tyminip`";
                $result = mysqli_query($conn, $sql);
                $sql1 = "SELECT * FROM `login_tyminip`";
                $result1 = mysqli_query($conn, $sql1);
                $id = 0;
                while ($row = mysqli_fetch_assoc($result) ) {
                    $id = $id + 1;
                        


                    echo "<tr>
                        <th scope='row'>" . $id . "</th>
                <td>" . $row['rpn'] . "</td>
                <td>" . $row['author'] . "</td>
                <td>" . $row['pub_dt'] . "</td>
                <td>" . $row['type'] . "</td>
                <td>" . $row['keyword'] . "</td>
                <td>" . $row['volume'] . "</td>
                <td>" . $row['nmcj'] . "</td>
                <td>" . $row['pg'] . "</td>
                <td>" . $row['weblink'] . "</td>
                
                <td><a href='files/" . $row['filename'] . "'</a><button type='button' class='edit btn btn-sm btn-primary' >Download</button></td>
                <td> </td>
                 
            </tr>";
                }


                ?>



            </tbody>
        </table>
    </div>
    <!-- for search filter -->
    <script>
        (function(document) {
            'use strict';

            var TableFilter = (function(myArray) {
                var search_input;

                function _onInputSearch(e) {
                    search_input = e.target;
                    var tables = document.getElementsByClassName(search_input.getAttribute('data-table'));
                    myArray.forEach.call(tables, function(table) {
                        myArray.forEach.call(table.tBodies, function(tbody) {
                            myArray.forEach.call(tbody.rows, function(row) {
                                var text_content = row.textContent.toLowerCase();
                                var search_val = search_input.value.toLowerCase();
                                row.style.display = text_content.indexOf(search_val) > -1 ? '' : 'none';
                            });
                        });
                    });
                }

                return {
                    init: function() {
                        var inputs = document.getElementsByClassName('search-input');
                        myArray.forEach.call(inputs, function(input) {
                            input.oninput = _onInputSearch;
                        });
                    }
                };
            })(Array.prototype);

            document.addEventListener('readystatechange', function() {
                if (document.readyState === 'complete') {
                    TableFilter.init();
                }
            });

        })(document);
    </script>
    <!-- end search filter -->
    </div>
    </div>

    <!-- modal -->
    <!-- jQuery -->

    <!-- end modal -->

    <!-- MODAL TOGGLE STRT -->



    <!-- MODAL TOGGLE ENDS -->
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>





    <script>
        edits = document.getElementsByClassName('edit');
        Array.from(edits).forEach((element) => {
            element.addEventListener("click", (e) => {
                console.log("edit ", );
                tr = e.target.parentNode.parentNode;
                company = tr.getElementsByTagName("td")[0].innerText;
                lable = tr.getElementsByTagName("td")[1].innerText;
                productname = tr.getElementsByTagName("td")[2].innerText;
                quantity = tr.getElementsByTagName("td")[3].innerText;
                sellprice = tr.getElementsByTagName("td")[4].innerText;
                originalprice = tr.getElementsByTagName("td")[5].innerText;
                console.log(company, lable, productname, quantity, sellprice);
                editcompany.value = company;
                editlable.value = lable;
                editproductname.value = productname;
                editquantity.value = quantity;
                editpricesell.value = sellprice;
                editpriceoriginal.value = originalprice;
                editid.value = e.target.id;

                console.log(e.target.id);
                $('#editModal').modal('toggle');
                console.log(e.target.datetime);

            })
        })

        //for delete ...down
        deletes = document.getElementsByClassName('delete');
        Array.from(deletes).forEach((element) => {
            element.addEventListener("click", (e) => {
                console.log("edit ");

                id = e.target.id.substr(1);

                if (confirm("Are you sure you want to delete this note!")) {
                    console.log("yes");
                    $del = window.location = `/cms/templates/inventory.php?delete=${id}`;
                    if ($del == true) {
                        window.location.reload("index.php");
                    }

                    // TODO: Create a form and use post request to submit a form
                } else {
                    console.log("no");
                }


            })
        })
    </script>







</body>

</html>
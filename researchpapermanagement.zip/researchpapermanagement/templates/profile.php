
<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
}



require_once("../config/config.php");







?>



<!DOCTYPE html>
<html lang="en">

<head>
    <!-- CSS only -->

    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">

    <link rel="stylesheet" href="../css/logout.css">
    <link rel="stylesheet" href="../css/additem.css">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/inventory.css">
    <link rel="stylesheet" href="../css/profile.css">

    <style type="text/css">
 .lgot{
   position:absolute;
   top:0;
   right:10px;
  }
</style>



    <title>Research Paper Management System</title>



</head>
<body>
<div class="topbar">
        <div class="logo">
            <h2>Research Paper <span>Management System</span></h2>
        </div>
        <!-- <div class="ca">
            <div class="cabt">
                <div class="invtop">
                    <button class="button">Inventory</button>
                </div>

            </div>
        </div> -->
        <!-- <div class="user">
            <h4>
                //<?php echo " " . $_SESSION['username']; ?>
            </h4>
             <img src="../img/pexels-bich-tran-669996.jpg" alt=""> -->
    </div>
    </div><div class="lgot">
            <a href="logout.php">Logout</a>
        </div>
    <div class="navinv">
        <div class="wrapper">
            <a href="./index.php"><span>Home</span></a>
        </div>

        
        <div class="wrapper">
            <a href="./add.php"><span>Add Paper</span></a>
        </div>
        <div class="wrapper">
            <a href="logout.php"><span>Profile</span></a>
        </div>
        
    </div>


    <div class="tab-content col-md-12" 
">
<?php
$user = $_SESSION["username"];
$r= "SELECT * from login_tyminip where username='$user'";
$rs = mysqli_query($conn, $r);
$row12 = mysqli_fetch_assoc($rs);
   $sfn=  $row12['fname']  ;
   $sln=  $row12['lname']  ;
   $sclg=  $row12['clgname']  ;
   $sbr=  $row12['brnm']  ;
   $smbn=  $row12['mbn']  ;
   $sbdt=  $row12['bdt']  ;
   $sus=  $row12['username']  ;
   $rl=  $row12['rl']  ;
   
?>
      
    <h6> Name : <?php echo "$sfn  $sln"; ?>
    
    <h6> Role : <?php echo "$rl"; ?>
    <br>
    Collge Name : <?php echo "$sclg "; ?>
    <br>
    Branch : <?php echo "$sbr "; ?>
    <br>
    Contact Number : <?php echo "$smbn "; ?>
    <br>
    Email: <?php echo "$sus "; ?>
    <br>
    Birth Date: <?php echo "$sbdt "; ?></h6>
    

    
    
    
    
    
    
    </div><a href="editprof.php">
    <button type="button" class="btn btn-primary"> Edit Information</button></a>



</body>
<?php
 session_start();





 error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);
ini_set('display_errors', 1);
 require_once("../config/config.php");
$invd = false;
$suc = false;
$invd1 = false;
 
if (isset($_POST['re_password']))
	{
	$username = $_POST['username'];
    $bdt = $_POST['bdt'];
	$new_pass = $_POST['new_pass'];
	$re_pass = $_POST['re_pass'];
	$password_query = ("SELECT * from login_tyminip where username='$username' && bdt='$bdt'");
    $res = mysqli_query($conn,$password_query);
	$password_row = mysqli_fetch_array($res);
	$database_password = $password_row['username'];
    $database_password1 = $password_row['bdt'];
	if ($database_password == $username && $database_password1== $bdt)
		{
		if ($new_pass == $re_pass)
			{
                $param_password = password_hash($new_pass, PASSWORD_DEFAULT);
			$update_pwd = "UPDATE login_tyminip set password='$param_password' where username='$username'";
            $re1 = mysqli_query($conn,$update_pwd);

            $stmt = mysqli_prepare($conn, $update_pwd);
            
                // $param_password = password_hash($new_pass, PASSWORD_DEFAULT);
                
                // // TRY TO EXECUTE QUERY
                // if ($param_password) {
                //     echo "hash done";
                // } else {
                //     echo "Something went wrong... redirect";
                //     $swr1 = true;
                // }




			//echo "('Update Sucessfully')";
            $suc = true;
			}
		  else
			{
			//echo "('Your new and Retype Password is not match'); ";
            $invd1 = true;
			}
		}
	  else
		{
		//echo "('Email or birth date is wrong');";
        $invd = true;
		}
	}
 
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <!-- Required meta tags -->
   <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/logout.css">
    <title>Research Paper Management System</title>

    <style>
        body{
            background-color: black;
            color: wheat;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Research Paper Management System</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Register <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="login.php">Login</a>
                </li>
               



            </ul>
        </div>
    </nav>
<?php 
    if ($invd1) {
        echo "<div class='alert alert-danger alert-dismissible fade show' role='alert'>
        Password not matching
        <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
    <span aria-hidden='true'>&times;</span>
  </button>
      </div>";
    }
    elseif ($invd) {
        echo "<div class='alert alert-danger' alert-dismissible fade show' role='alert'>
        Invalid Email or Birth Date
        <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
    <span aria-hidden='true'>&times;</span>
  </button>
      </div>";
    }
    elseif ($suc) {
        echo "<div class='alert alert-success' alert-dismissible fade show' role='alert'>
        Password update success. Please go to login page and login with new password...
        <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
    <span aria-hidden='true'>&times;</span>
  </button>
      </div>";
    }


?>





    <div class="container mt-4">
        <h3>Forgot Password?</h3>
        <hr>
        <form action="" method="post">
            <div class="form-row">
            
            




                <div class="form-group col-md-6">
                    <label for="inputEmail4">Email</label>
                    <input type="email" class="form-control" name="username" id="inputEmail4" placeholder="Email">
                </div>
                <div class="form-group col-md-6">
                    <label for="bdt">Enter Birth Date</label>
                    <input type="date" class="form-control" name="bdt" id="bdt">
                </div>
                <div class="form-group col-md-6">
                    <label for="inputPasswordnw">New Password</label>
                    <input type="password" class="form-control" name="new_pass" id="inputPassword4" placeholder="New Password">
                </div>

                <div class="form-group col-md-6">
                <label for="inputPasswordnw">Confirm New Password</label>
                <input type="password" class="form-control" name="re_pass" id="inputPassword" placeholder="Confirm Password">
    </div>
          
                
                
            </div>
            <button type="submit" name="re_password" class="btn btn-primary">Change Password</button>

            </div>
            
            
            
        </form>




        <script>
        $('.alert').alert()
    </script>


<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
















<!-- <div style="width:30%;">
   <form method="post" action="">
      <div>
         <label style="color:blue;">Email</label>
         <input type="email" name="username" placeholder="Enter email">
      </div>
      <div>
         <label style="color:blue;">Bdt</label>
         <input type="date" name="bdt" placeholder="Enter bdt">
      </div>
      <div>
         <label style="color:blue;">New Password</label>
         <input type="password" name="new_pass" placeholder="New Password . . . . .">
      </div>
      <div>
         <label style="color:blue;">Re-Type New Password</label>
         <input type="password" name="re_pass" placeholder="Re-Type New Password . . . . .">
      </div>
      <button type="submit" name="re_password">Submit</button>
   </form>
</div>
</body>
</html> -->
<?php
	session_start();
    require_once("../config/config.php");



    if(isset($_POST['update'])){
		//get POST data
		$old = $_POST['olbdt'];
		$new = $_POST['nwpassword'];
		$retype = $_POST['confirm_nwpassword'];
        $email = $_POST['email'];

        $_SESSION['olbdt'] = $old;
		$_SESSION['nwpassword'] = $new;
		$_SESSION['confirm_nwpassword'] = $retype;


        $query = "SELECT * from login_tyminip where username=$email";
        $res=mysqli_query($conn,$query);
        $row = mysqli_fetch_assoc($res);
        
        

        
    }


    if ($_SERVER['Request_Method'] = "update") {

        $sql = "SELECT id, username, password FROM login_tyminip WHERE username = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "s", $param_username);
        $param_username = $username;


    }









    ?>









<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Research Paper Management System</title>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Research Paper Management System</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Register <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="login.php">Login</a>
                </li>
               



            </ul>
        </div>
    </nav>

    <div class="container mt-4">
        <h3>Please Register Here:</h3>
        <hr>
        <form action="" method="update">
            <div class="form-row">
            
            




                <div class="form-group col-md-6">
                    <label for="inputEmail4">Email</label>
                    <input type="email" class="form-control" name="email" id="inputEmail4" placeholder="Email">
                </div>
                <div class="form-group col-md-6">
                    <label for="bdt">Enter Birth Date</label>
                    <input type="date" class="form-control" name="olbdt" id="bdt">
                </div>
                <div class="form-group col-md-6">
                    <label for="inputPasswordnw">New Password</label>
                    <input type="password" class="form-control" name="nwpassword" id="inputPassword4" placeholder="New Password">
                </div>

                <div class="form-group col-md-6">
                <label for="inputPasswordnw">Confirm New Password</label>
                <input type="password" class="form-control" name="confirm_nwpassword" id="inputPassword" placeholder="Confirm Password">
            </div>
            <?php 
            $sql = "SELECT * FROM `tyminip` where user_id=$id ";
            $result = mysqli_query($conn, $sql); 
            while ($row = mysqli_fetch_assoc($result)) {
                echo $row['rpn'];
            }
            
            ?>
          
                
                
            </div>
            <button type="submit" class="btn btn-primary">Sign Up</button>

            </div>
            
            
            
        </form>
    </div>
<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
}


require_once("../config/config.php");

$sql = "SELECT username FROM `login_tyminip` ";
$result = mysqli_query($conn, $sql);
$insert = false;

$user = $_SESSION["username"];
$id = $_SESSION["id"];




if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $rpn = $_POST["rpn"];
    $author = $_POST["author"];
    $pub_dt = $_POST["pub_dt"];
    $keyword = $_POST["keyword"];
    // $detail = $_POST["detail"];
    $type = $_POST["type"];

    $volume = $_POST["volume"];
    $nmcj = $_POST["nmcj"];
    $pg = $_POST["pg"];
    $weblink = $_POST["weblink"];





    $fileName = $_FILES['file']['name'];
        $fileTmpName = $_FILES['file']['tmp_name'];
        $path = "files/".$fileName;
        
        $query = "INSERT INTO tyminip(filename,rpn,author,pub_dt,keyword,type,user_id,volume,nmcj,pg,weblink) VALUES ('$fileName','$rpn','$author','$pub_dt','$keyword','$type','$id','$volume','$nmcj','$pg','$weblink')";
        $run = mysqli_query($conn,$query);
        
        if($run){
            move_uploaded_file($fileTmpName,$path);
            echo "success";
        }
        else{
            echo "error".mysqli_error($conn);
        }
}


/*
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $rpn = $_POST["rpn"];
    $author = $_POST["author"];
    $pub_dt = $_POST["pub_dt"];
    $keyword = $_POST["keyword"];
    $filename = $_FILES["dl_loc"]["name"];
    $temp_name = $_FILES["dl_loc"]["tmp_name"];
    $dl_loc = "dl_loc/" . $filename;
    $up_by =  "$_SESSION[username]";
    move_uploaded_file($temp_name, $dl_loc);

    if ($filename != "") {
        $sql = "INSERT INTO `data` (`rpn`,`author`,`pub_dt`,`type`,`keyword`,`dl_loc`,`up_by`) VALUES ('$rpn','$author','$pub_dt','type','$keyword','$dl_loc','$up_by')";
        $result = mysqli_query($conn, $sql);

        if ($result) {
            // echo "Inserted Successfully <br>";
            $insert = true;
        } else {
            echo "Problem Inserting <br>";
        }
    }
}

*/
//sql query execute







?>


<?php



?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">

    <script type="text/javascript" src="http://code.jquery.com/jquery-1.7.1.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/inventory.css">
    <link rel="stylesheet" href="../css/additem.css">

    <title>Admin-Research Paper Management System</title>

</head>

<body>
    <div class="topbar">
        <div class="logo">
            <h2>Research Paper<span>Management System</span></h2>
        </div>
        <!-- <div class="ca">
            <div class="cabt">
                <div class="invtop">
                    <button class="button">Add Paper</button>
                </div>

            </div>
        </div> -->
        <!-- <div class="user">
            <h4>Name</h4>
            <img src="../img/pexels-bich-tran-669996.jpg" alt="">
        </div> -->
    </div>
    <div class="navinv">
        

        <div class="wrapper">
            <a href="index.php"><span>Research Papers</span></a>
        </div>

        <div class="wrapper">
            <a href="admin.php"><span>Admin</span></a>
        </div>
        <div class="wrapper">
            <a href="logout.php"><span>Logout</span></a>
        </div>
        <!-- <div class="wrapper">
            <a href="./inventory.php"><span>Inventory</span></a>
        </div> -->
    </div>
    <?php
    if ($insert) {
        echo "<div class='alert alert-success' role='alert'>
        Paper added Successfully!! :)
      </div>";
    }
    ?>
    <div class="addfo">
        <div class="container">

            <form action="" method="POST" enctype="multipart/form-data">
                <label for="compony">Research Paper Name</label>
                <input type="text" id="rpn" name="rpn" placeholder="Research Paper Name">

                <label for="lable">Author</label>
                <input type="text" id="author" name="author" placeholder="author name">
                <label for="pub_dt">Publish Date</label>
                <input type="date" id="pub_date" name="pub_dt" placeholder="Publish Date">

                <label for="type">Type</label>
                <select name="type" id="type" name="type">
                    <option value="gernal">Journal</option>
                    <option value="conference">Conference</option>
                </select>

                <label for="keyword">keyword</label>
                <input type="text" id="keyword" name="keyword" placeholder="keyword">
                <label for="detail">Volume Issued</label>
                <input type="text" id="detail" name="volume" placeholder="Volume Issued">

                <label for="nmcj">Name of conference/journal</label>
                <input type="text" id="nmcj" name="nmcj" placeholder="Name of conference/journal">

                <label for="pg">Page</label>
                <input type="text" id="detail" name="pg" placeholder="Page">

                <label for="Weblink">Weblink</label>
                <input type="text" id="detail" name="weblink" placeholder="Weblink">

                <label for="dl_loc">Upload File</label>
                <input id="file-input" type="file" name="file">


                <input type="submit" value="Submit" name="submit">
            </form>
        </div>
        <div class="container1">

        </div>
    </div>


</body>


</html>